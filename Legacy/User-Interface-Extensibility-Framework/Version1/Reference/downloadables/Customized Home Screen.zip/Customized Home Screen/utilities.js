﻿( function( utilities, $, undefined ) {

	// htmlencode.
	utilities.htmlencode = function( text, convertNewLine ) {

		// Handle null and undefined values.
		if( text == null || text == undefined )
			return "";
	
		// Encode value.
		var result = text.replace( /[&<>"']/g, function( $0 ) {
			return "&" + { "&": "amp", "<": "lt", ">": "gt", '"': "quot", "'": "#39"}[$0] + ";";
		} );

		// Convert also "new line" if requested.	
		if( convertNewLine )
			result = result.replace( /\n/gi, "<br />" );

		// return encoded value;
		return result;
	};
	
	// removeQuotes.
	utilities.removeQuotes = function( text ) {

		// Remove quotes.
		return text.replace( /["']/g, function( $0 ) {
			return { '"': "", "'": "" }[ $0 ];
		} );
	};

	utilities.escapeRegExp = function(str) {
	  return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
	};

	utilities.getHitRegExp = function(hits) {

		// return nothing if there is no hit text
		if(!hits)
			return;

		// turn hits text into a regexp
		hits = utilities.escapeRegExp( hits )
		hits = hits.split( /\n/gi );
		hits.sort( function(a,b) { return b.length - a.length;} );
		hits = hits.join("|" );				
		return new RegExp( hits, "i" );

	};

} ( window.utilities = window.utilities || {}, jQuery ) );
