﻿///////// localization
function localization() {

	// getText.
	this.getText = function( id ) {
	
		// Get localized text from MFShell.
		var localizedString = null;
		try {
			localizedString = MFiles.GetStringResource( id );
		}
		catch ( ex ) {
		}
		return ( localizedString != null ) ? localizedString : "";
	};

    // Map resource strings to the IDs in MFRes.dll.   
	this.strings = {};
	this.strings.IDS_HOMESCREEN_TITLE_CREATE_NEW = this.getText( 27622 );
	this.strings.IDS_HOMESCREEN_TITLE_LEARNING_RESOURCES = this.getText( 27623 );
	this.strings.IDS_HOMESCREEN_SUBTITLE_LEARN_MORE = this.getText( 27624 );
	this.strings.IDS_HOMESCREEN_SUBTITLE_GET_HELP = this.getText( 27625 );
	this.strings.IDS_HOMESCREEN_ITEM_OVERVIEW_VIDEO = this.getText( 27626 );
	this.strings.IDS_HOMESCREEN_ITEM_GUIDED_TOUR = this.getText( 27627 );
	this.strings.IDS_HOMESCREEN_ITEM_TRAINING = this.getText( 27628 );
	this.strings.IDS_HOMESCREEN_ITEM_USER_GUIDE = this.getText( 27629 );
	this.strings.IDS_HOMESCREEN_ITEM_TECHNICAL_DOCUMENTATION = this.getText( 27630 );
	this.strings.IDS_HOMESCREEN_ITEM_COMMUNITY = this.getText( 27631 );
	this.strings.IDS_HOMESCREEN_ITEM_CONTACT_SUPPORT = this.getText( 27632 );
	this.strings.IDS_HOMESCREEN_TITLE_VIEWS = this.getText( 27633 );
	this.strings.IDS_HOMESCREEN_NEW_DOCUMENT_FROM_SCANNER = this.getText( 27637 );
    this.strings.IDS_HOMESCREEN_TABNAME = this.getText( 27664 );  // This string id (27664) is used directly in the home.js so don't change it. Or if it is changed then change also the  corresponding value in home.js.
	this.strings.IDS_HOMESCREEN_NEW_VIEW = this.getText( 27665 );
};
