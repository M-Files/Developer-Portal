
"use strict";

function OnNewVaultCore( vaultCore ) {
	/// <summary>The entry point of VaultCore module.</summary>
	/// <param name="vaultCore" type="MFiles.VaultCore">The new vault core object.</param> 

	// Register to listen new vault entry creation event. 
	vaultCore.Events.Register( Event_NewVaultEntry, newVaultEntryHandler );
}

function newVaultEntryHandler( vaultEntry ) {
	/// <summary>Event handler to handle new vault entry object creations.</summary>
	/// <param name="vaultEntry" type="MFiles.VaultEntry">The new vault entry object.</param> 

	// Register to listen the 'OnSetPropertiesOfObjectVersion' event.
	vaultEntry.Events.Register( Event_SetPropertiesOfObjectVersion, getSetPropertiesOfObjectVersionHandler( vaultEntry ) );
}

function getSetPropertiesOfObjectVersionHandler( vaultEntry ) {
	/// <summary>Event handler to handle property setting events for single object.</summary>
	/// <param name="vaultEntry" type="IVaultEntry">The current vault entry object.</param> 
	/// <returns type="MFiles.Events.OnSetPropertiesOfObjectVersion">The event handler.</returns>

	// Return the event handler object.
	return function( setPropertiesParams ) {
		/// <summary>Event handler for 'OnSetPropertiesOfObjectVersion' event.<summary>
		/// <param name="setPropertiesParams" type="MFiles.SetPropertiesParams">
		/// The target object version and the change set in properties.
		/// </param>

		// Examine if the target object is checked out.
		if( vaultEntry.Vault.ObjectOperations.IsCheckedOut( setPropertiesParams.ObjVer.ObjID ) ) {

			// Resolve the current workflow and state.
			var oldWorkflowState = vaultEntry.Vault.ObjectPropertyOperations.GetWorkflowState( 
					setPropertiesParams.ObjVer, false );

			// Seek the new workflow and state.
			var workflowIndex = setPropertiesParams.PropertyValuesToSet.IndexOf( MFBuiltInPropertyDefWorkflow );
			var stateIndex = setPropertiesParams.PropertyValuesToSet.IndexOf( MFBuiltInPropertyDefState );

			// Check the workflow.                
			if( workflowIndex != -1 ) {

				// Workflow exists. Make sure that it is not changed.
				if( setPropertiesParams.PropertyValuesToSet.Item( workflowIndex ).Value.GetLookupID() !=
					oldWorkflowState.Workflow.Value.GetLookupID() ) {

					// Throw an error.
					throwErrorMustNotChangeWorkflowOrState();
				}

			} else {

				// Workflow not found. This is ok only if the workflow didn't exist previously, or the set is not full set.
				if( ! oldWorkflowState.Workflow.Value.IsUninitialized() &&
					! oldWorkflowState.Workflow.Value.IsNULL() &&
					setPropertiesParams.FullSet ) {

					// Throw an error.
					throwErrorMustNotChangeWorkflowOrState();
				}

			}  // end if ( workflow existence )

			// Check the state.                
			if( stateIndex != -1 ) {

				// State exists. Make sure that it is not changed.
				if( setPropertiesParams.PropertyValuesToSet.Item( stateIndex ).Value.GetLookupID() !=
					oldWorkflowState.State.Value.GetLookupID() ) {

					// Throw an error.
					throwErrorMustNotChangeWorkflowOrState();
				}

			} else {

				// State not found. This is ok only if the state didn't exist previously, or the set is not full set.
				if( ! oldWorkflowState.State.Value.IsUninitialized() &&
					! oldWorkflowState.State.Value.IsNULL() &&
					setPropertiesParams.FullSet ) {

					// Throw an error.
					throwErrorMustNotChangeWorkflowOrState();
				}

			}  // end if ( state existence )

			// Check for removed properties.
			var workflowIndexInRemoveSet = setPropertiesParams.PropertyValuesToRemove.IndexOf( MFBuiltInPropertyDefWorkflow );
			var stateIndexInRemoveSet = setPropertiesParams.PropertyValuesToRemove.IndexOf( MFBuiltInPropertyDefState );

			// Must not try to remove workflow or state.
			if( workflowIndexInRemoveSet != -1 || stateIndexInRemoveSet != -1 )
				throwErrorMustNotChangeWorkflowOrState();

		}  // end if ( object is checked out )
	};
}

function throwErrorMustNotChangeWorkflowOrState() {
	/// <summary>Throws an error indicating that workflow or state must not be be changed for checked out objects.</summary>

	// Throw an error.
	MFiles.ThrowError( 'The workflow or state cannot be be changed for an object that is checked out.' );
}
