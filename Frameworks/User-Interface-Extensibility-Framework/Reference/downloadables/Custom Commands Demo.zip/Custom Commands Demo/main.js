
"use strict";

function OnNewShellUI( shellUI ) {
	/// <summary>The entry point of ShellUI module.</summary>
	/// <param name="shellUI" type="MFiles.ShellUI">The new shell UI object.</param> 

	// Register to listen new shell frame creation event.
	shellUI.Events.Register( Event_NewShellFrame, newShellFrameHandler );
}

function newShellFrameHandler( shellFrame ) {
	/// <summary>Handles the OnNewShellFrame event.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The new shell frame object.</param> 

	// Register to listen the started event.
	shellFrame.Events.Register( Event_Started, getShellFrameStartedHandler( shellFrame ) );
}

function getShellFrameStartedHandler( shellFrame ) {
	/// <summary>Gets a function to handle the Started event for shell frame.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The current shell frame object.</param> 
	/// <returns type="MFiles.Events.OnStarted">The event handler.</returns>

	// Return the handler function for Started event.
	return function() {
	
		// Shell frame object is now started.
		
		// Create some commands.
		var commandShow1 = shellFrame.Commands.CreateCustomCommand( "Show Message #1" );
		var commandShow2 = shellFrame.Commands.CreateCustomCommand( "Show Message #2" );

		// Set command icons.
		shellFrame.Commands.SetIconFromPath( commandShow1, "png/tennis_ball.ico" );
		shellFrame.Commands.SetIconFromPath( commandShow2, "png/flower_red.ico" );
		
		// Add a command to the context menu.
		shellFrame.Commands.AddCustomCommandToMenu( commandShow1, MenuLocation_ContextMenu_Bottom, 0 );
		
		// Add a commands to the task pane.
		shellFrame.TaskPane.AddCustomCommandToGroup( commandShow1, TaskPaneGroup_Main, -101 );
		shellFrame.TaskPane.AddCustomCommandToGroup( commandShow2, TaskPaneGroup_Main, -100 );
		
		// Set the command handler function.
		shellFrame.Commands.Events.Register( Event_CustomCommand, function( command ) {
		
			// Branch by command.
			if( command == commandShow1 ) {
			
				// Show a message.
				shellFrame.ShowPopupDashboard( "popup_message", true, 
						{ caption: "Hello!", message: "Hello #1" } );

			} else if( command == commandShow2 ) {
			
				// Show a message.
				shellFrame.ShowPopupDashboard( "popup_message", true, 
						{ caption: "Hello!", message: "Hello #2" } );
			}
		} );
	};
}
