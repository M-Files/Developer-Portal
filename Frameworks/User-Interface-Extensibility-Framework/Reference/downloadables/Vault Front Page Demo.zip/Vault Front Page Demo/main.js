
"use strict";

function OnNewShellUI( shellUI ) {
	/// <summary>The entry point of ShellUI module.</summary>
	/// <param name="shellUI" type="MFiles.ShellUI">The new shell UI object.</param> 

	// Register to listen new shell frame creation event. This reacts to normal shell frames only (not e.g. common dialog nor embedded shell frames).
	shellUI.Events.Register( Event_NewNormalShellFrame, newShellFrameHandler );
}

function newShellFrameHandler( shellFrame ) {
	/// <summary>Event handler to handle new shell frame object creations.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The new shell frame object.</param> 

	// Register to listen the started event.
	shellFrame.Events.Register( Event_Started, getShellFrameStartedHandler( shellFrame ) );
}

function getShellFrameStartedHandler( shellFrame ) {
	/// <summary>Gets the event handler for "started" event of a shell frame.<summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The current shell frame object.</param>
	/// <returns type="MFiles.Event.OnStarted">The event handler object</returns>

	// Return the handler function for Started event.
	return function() {
		/// <summary>The "started" event handler implementation for a shell frame.<summary>
	
		// Shell frame object is now started. Check if this is the root view.
		if( shellFrame.CurrentPath == "" ) {
		
			// This is the vault root.
			
			// Hide all panes. Task and Search panes may be missing.
			if( shellFrame.TaskPane.Available )
				shellFrame.TaskPane.Visible = false;
			if( shellFrame.SearchPane.Available )
				shellFrame.SearchPane.Visible = false;
			shellFrame.RightPane.Visible = false;
			shellFrame.BottomPane.Visible = false;
			
			// Replace the listing with a dashboard.
			shellFrame.ShowDashboard( "front_page", null );
		}        
	};
}
