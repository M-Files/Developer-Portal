import { defineConfig } from 'vite';
import { copyFileSync } from 'fs';
import { execSync } from 'child_process';

export default defineConfig({
  build: {
    lib: {
      entry: 'main.js',
      formats: ['iife'],
      name: 'window',
      fileName: () => 'main.js',
    },
    outDir: 'dist',
    minify: false,
    rollupOptions: {
      output: {
        // Extend window instead of creating a new variable.
        // This places exported functions (e.g. OnNewShellUI) directly
        // on the global scope so M-Files can call them.
        extend: true,
      },
    },
  },
  plugins: [{
    name: 'package-app',
    closeBundle() {
      copyFileSync('appdef.xml', 'dist/appdef.xml');
      // Create a deployable zip from the dist folder.
      execSync(
        'powershell -Command "Compress-Archive -Path dist/appdef.xml,dist/main.js -DestinationPath dist/app.zip -Force"',
      );
    },
  }],
});
