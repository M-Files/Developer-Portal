import { MFGrpc, Datatype, ConditionType, StatusType } from '@m-filescorporation/uix-vault-messages';

export function OnNewShellUI(shellUI) {
  /// <summary>The entry point of ShellUI module.</summary>
  /// <param name="shellUI" type="MFiles.ShellUI">The new shell UI object.</param>

  // Register to be notified when a new shell frame is created.
  shellUI.Events.Register(MFiles.Event.NewShellFrame, handleNewShellFrame);
}

function handleNewShellFrame(shellFrame) {
  /// <summary>Handles the OnNewShellFrame event for an IShellUI.</summary>
  /// <param name="shellFrame" type="MFiles.ShellFrame">The shell frame object which was created.</param>

  // Register to listen to the started event.
  shellFrame.Events.Register(
    MFiles.Event.Started,
    getShellFrameStartedHandler(shellFrame),
  );
}

function getShellFrameStartedHandler(shellFrame) {
  /// <summary>Gets a function to handle the Started event for shell frame.</summary>
  /// <param name="shellFrame" type="MFiles.ShellFrame">The current shell frame object.</param>
  /// <returns type="MFiles.Events.OnStarted">The event handler.</returns>

  // Return the handler function for ShellFrame's Started event.
  return async () => {
    // Create a command button in the top menu.
    const searchCommandId =
      await shellFrame.Commands.CreateCustomCommand('Search Documents');

    // Add the command to the main menu.
    await shellFrame.Commands.AddCustomCommandToMenu(
      searchCommandId,
      MFiles.MenuLocation.MenuLocation_TopPaneMenu,
      1,
    );

    // Set the command as active (visible and enabled).
    await shellFrame.Commands.SetCommandState(
      searchCommandId,
      MFiles.CommandLocation.All,
      MFiles.CommandState.CommandState_Active,
    );

    // Register to respond to commands being clicked.
    shellFrame.Commands.Events.Register(
      MFiles.Event.CustomCommand,
      async (command) => {
        // We only care about our command.
        // If the command being clicked is something else then return.
        if (command !== searchCommandId) {
          return;
        }

        // Search for documents and display results.
        await searchAndDisplayResults(shellFrame);
      },
    );
  };
}

function buildDocumentSearchConditions(keyword) {
  /// <summary>Builds search conditions for finding documents by keyword.</summary>
  /// <param name="keyword" type="string">The keyword to search for in document titles.</param>
  /// <returns type="SearchConditionArray">The search conditions.</returns>

  // Create a new SearchConditionArray and build conditions using chaining.
  // Status() and Property() return the array, so calls can be chained.
  const conditions = MFGrpc.SearchConditionArray.Create()

    // Filter by object type: Documents (type 0).
    .Status(
      StatusType.STATUS_TYPE_OBJECT_TYPE,
      ConditionType.CONDITION_TYPE_EQUAL,
      Datatype.DATATYPE_LOOKUP,
      MFGrpc.Lookup.Create(0),
    )

    // Exclude deleted objects.
    .Status(
      StatusType.STATUS_TYPE_IS_DELETED,
      ConditionType.CONDITION_TYPE_EQUAL,
      Datatype.DATATYPE_BOOLEAN,
      false,
    )

    // Search "Name or Title" property (ID 0) for the keyword.
    .Property(
      0,
      ConditionType.CONDITION_TYPE_CONTAINS,
      Datatype.DATATYPE_TEXT,
      keyword,
    );

  return conditions;
}

async function searchAndDisplayResults(shellFrame) {
  /// <summary>Searches for documents and displays results in a message box.</summary>
  /// <param name="shellFrame" type="MFiles.ShellFrame">The current shell frame object.</param>

  try {
    // Get the vault reference.
    const iVault = shellFrame.ShellUI.Vault;

    // Build search conditions using package helpers.
    const conditions = buildDocumentSearchConditions('Report');

    // Execute the search.
    // Use toJSON() to convert proxy objects to plain data — proxy
    // objects cannot be sent over PostMessage to the vault.
    const searchResponse = await iVault.SearchOperations.SearchObjects({
      call_importance: 1, // CallImportance.CALL_IMPORTANCE_NORMAL
      target: {
        mode: 0, // SearchMode.SEARCH_MODE_DEFAULT
      },
      conditions: [conditions.toJSON()],
      options: {},
      limit: 10,
      timeout_in_seconds: 30,
    });

    // Process the results.
    const results = searchResponse.results || [];

    if (results.length === 0) {
      await shellFrame.ShowMessage('No documents found matching "Report".');
      return;
    }

    // Read object metadata from each search result.
    const summaryLines = results.map((result) => {
      // Wrap the server response to get access to helper properties
      // like Title and ID, instead of navigating deeply nested JSON.
      const objVerEx = new MFGrpc.ObjectVersionEx(result.object);

      const title = objVerEx.Title;
      const id = objVerEx.ID;
      const version = objVerEx.Version;

      return `- ${title} (ID: ${id}, Version: ${version})`;
    });

    const message = `Found ${results.length} document(s):\n\n${summaryLines.join('\n')}`;
    await shellFrame.ShowMessage(message);

  } catch (exception) {
    console.error('Search failed:', exception);
    MFiles.ReportException(exception);
  }
}
