
function setTheme( shellFrame ) {
	/// <summary>Event handler to handle new shell frame object creations.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The new shell frame object.</param> 

	// Change the task pane theme if the task pane is available.
	if( shellFrame.TaskPane.Available ) {
	
		// Set the task pane theme.
		shellFrame.TaskPane.SetTheme({
		
			// Text color and background color for group header on the task pane (such as 'New' or 'Go To' text).
			groupHeader_TextColor: '#000000',
			groupHeader_BackgroundColor: '#a0a0a0',
			
			// Text color and background color for group header on the task pane (such as 'New' or 'Go To' text),
			// to be used when the group header is highlighted (e.g. mouse cursor is hovered over the group header).
			groupHeader_HighlightTextColor: '#ffffff',
			groupHeader_HighlightBackgroundColor: '#000000',
			
			// Icon files for exapanding and collapsing a task pane item group. The icon file must be in .ico file format.
			// The .ico file should contain at least icon with 16 x 16 dimensions, larger sizes may be used with 
			// high screen dpi settings.
			//groupHeader_IconFileExpand: '',
			//groupHeader_IconFileCollapse: '',
			
			// Group header font sizes.  The compact layout is enabled (by default) if the primary screen vertical
			// resolution is less than 900 pixels.
			//groupHeader_FontSize: '100%',
			//groupHeader_FontSizeCompact: '100%',
			
			// Text color and background color for action items on the task pane.
			item_TextColor: '#000000',
			item_BackgroundColor: '#909090',
			
			// Text color and background color for action items on the task pane, to be used when the item is 
			// highlighted (e.g. mouse cursor is hovered over the group header).
			item_HighlightTextColor: '#FFFFFF',
			item_HighlightBackgroundColor: '#000000',
			
			// The font size for task pane action items.
			//item_FontSize: '100%',
			
			// The color for divider line in between task pane items and groups.
			dividerColor: '#808080',
			
			last: 0
		});
		
		// Change the logo. The logo must be 32-bit png image (i.e. png with alpha channel transparency).
		shellFrame.TaskPane.SetLogo( 'logo.png' );
	}

	// Change the search pane theme if the search pane is available.
	if( shellFrame.SearchPane.Available )
	{
		// Set the search pane theme.
		shellFrame.SearchPane.SetTheme({

			// The search pane background color. The background color shows up e.g. as a background of advanced search conditions.
			backgroundColor: '#808080',
			
			// The icon and background color for the search button. The icon file should be in ico format.
			//searchButton_IconFile: '',
			searchButton_BackgroundColor: '#000000',

			// The text and font size for the vault name.
			vaultName_TextColor: '#000000',
			//vaultName_FontSize: '100%',			

			// The text color and the icon for the 'go online' button on search pane. The button is visible in offline mode.
			// The icon file should be in ico format.
			goOnlineButton_TextColor: '#000000',
			//goOnlineButton_IconFile: '',
			
			// The text color for the user name. The user name shows up on the login pane
			// (i.e. the right part of the search pane).
			userName_TextColor: '#000000',			
			
			// The icon to display next to the user name on the login pane (i.e. the right part of the search pane).
			// The icon file should be in ico format.
			//loginPanePopupButton_IconFile: '',

			// The text color and icons for showing and hiding the advanced search options.
			// The icon files should be in ico format.
			advancedSearchButton_TextColor: '#000000',
			//advancedSearchButton_IconFileShow: '',
			//advancedSearchButton_IconFileHide: '',
			
			// The text color for 'Search within this folder' button. The button is located in the advanced search area.
			//searchWithinThisFolderButton_TextColor: '#000000',
		
			// The text color for 'All words / Any words / Boolean' selector texts. These texts are located in the advanced search area.
			//searchFlagsButtons_TextColor: '#000000',
			
			// The text color and icon file for 'Reset All' button. The button is located in the advanced search area.
			// The icon files should be in ico format.
			resetAllButton_TextColor: '#000000',			
			//resetAllButton_IconFile: '',
			
			// The text color and icon file for 'Additional conditions' button. The button is located in the advanced search area.
			// The icon files should be in ico format.
			additionalConditionsButton_TextColor: '#000000',
			//additionalConditionsButton_IconFile: '',
			
			last: 0
		});
	}

	// Set the listing area theme.
	shellFrame.Listing.SetTheme({

		// Listing area colors for texts and backgrounds for listing items.
		//item_TextColor_Hot: '#ffffff',
		//item_TextColor_Selected: '#ffffff',
		//item_TextColor_HotSelected: '#ffffff',
		//item_TextColor_SelectedNoFocus: '#ffffff',
		//item_BackgroundColor_Hot: '#000000',
		//item_BackgroundColor_Selected: '#000000',
		//item_BackgroundColor_HotSelected: '#000000',
		//item_BackgroundColor_SelectedNoFocus: '#000000',
		
		// Listing area colors for texts and backgrounds for grouping headers.
		//groupHeader_LabelColor: '#ffffff',
		//groupHeader_LineColor: '#ffffff',
		//groupHeader_ButtonTextColor: 'default',
		//groupHeader_ButtonEdgeHighlightColor: 'default',
		//groupHeader_ButtonHighlightColor: 'default',
		//groupHeader_BackgroundColor: '#000000',
		//groupHeader_BackgroundColor_Hot: '#000000',
		//groupHeader_BackgroundColor_Selected: '#000000',		
		//groupHeader_BackgroundColor_HotSelected: '#000000',
		
		// Listing area colors for sorting headers (main headers).
		//sortableHeader_DividerColor_Inactive: '#000000',
		//sortableHeader_DividerColor_Active: '#000000',
		sortableHeader_BackgroundColor_Inactive: '#707070',
		sortableHeader_BackgroundColor_Active: '#000000',
		
		// The listing area background image.
		//backgroundImage: '',
		
		last: 0
		
	});

	shellFrame.SetTheme({		
		
		// The plain background color; set background_BitmapsEnabled to false to specify a plain background color everywhere instead of background images.
		//background_BitmapsEnabled: true,  
		//background_Color: '#ffffff',  //!< The background color.
		
		// Task pane background tiles. The tiles should be in png file format.
		background_TaskPane_BottomRightBitmapFile: 'TaskPaneBottomRight.png',
		background_TaskPane_BottomMiddleBitmapFile: 'TaskPaneBottomMiddle.png',
		background_TaskPane_BottomLeftBitmapFile: 'TaskPaneBottomLeftTile.png',
		background_TaskPane_MidRightBitmapFile: 'TaskPaneMidRight.png',
		background_TaskPane_MidLeftBitmapFile: 'TaskPaneMidLeftTile.png',
		background_TaskPane_TopRightBitmapFile: 'TaskPaneTopRight.png',
		background_TaskPane_TopLeftBitmapFile: 'TaskPaneTopLeftTile.png',
		
		// Search pane background tiles. The tiles should be in png file format.
		background_SearchPane_TopBitmapFile: 'SearchPaneTopTile.png',
		background_SearchPane_DownAndRightBitmapFile: 'SearchPaneDownAndRightTile.png',
		background_LoginPane_TopBitmapFile: 'LoginPaneTopTile.png',
		background_LoginPane_DownAndRightBitmapFile: 'LoginPaneDownAndRightTile.png',
		
		last: 0
	});
}

function OnNewShellUI( shellUI ) {
	/// <summary>The entry point of ShellUI module.</summary>
	/// <param name="shellUI" type="MFiles.ShellUI">The new shell UI object.</param> 

	// Register to listen new shell frame creation event.
	shellUI.Events.Register( MFiles.Event.NewShellFrame, newShellFrameHandler );
}

function newShellFrameHandler( shellFrame ) {
	/// <summary>Event handler to handle new shell frame object creations.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The new shell frame object.</param> 

	// Register to listen the started event.
	shellFrame.Events.Register( MFiles.Event.Started, function() {
		/// <summary>The event handler for "started" event of a shell frame.<summary>

		// Set the theme.
		setTheme( shellFrame );
	} );
}
