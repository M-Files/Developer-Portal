$inkscapeExe = "C:\Program Files\Inkscape\inkscape.exe"
$imagemagicExe = "C:\Program Files\ImageMagick\convert.exe"
$svgFolderRaw = "."
$svgFolder = "./svg"

$svgFiles = Get-ChildItem $svgFolderRaw -Filter *.svg
$pause = 0
				$foldername = "svg"
				new-item ./ -Name $foldername -Force -ItemType directory
				$foldername = "pdf"
				new-item ./ -Name $foldername -Force -ItemType directory
				

$c=0
if ($svgFiles.Length -ne 0){

    Write-Host "All" $svgFiles.Length "icon to output"
    	
    foreach ($svgFile in $svgFiles)
    {
        $inputParam  = $svgFile.FullName 

	    $outputParam = "--export-plain-svg="  + ".\svg\" + $svgFile.BaseName + ".svg"
	    & $inkscapeExe $inputParam $outputParam
	    $pause += 1
	
	    sleep -seconds 1
	
	    $inputParam  = ".\svg\" + $svgFile.BaseName + ".svg"
	                    
	$outputParam = '--export-pdf=' + '.\pdf\' + $svgFile.BaseName + '.pdf'
	& $inkscapeExe $inputParam $outputParam 
                    
        $c =$c+1
        sleep -seconds 1
        Write-Host $c "/" $svgFiles.Length $svgFile.BaseName
	    rm $svgFile
    }
} 
Else {

$svgFiles = Get-ChildItem $svgFolder -Filter *.svg
foreach ($svgFile in $svgFiles)
{
    $inputParam  = $svgFile.FullName 
	$outputParam = '--export-pdf=' + '.\pdf\' + $svgFile.BaseName + '.pdf'
	& $inkscapeExe $inputParam $outputParam 
                
sleep -seconds 5
#collect png to ico
#    $inputParam  = $svgFile.BaseName + "??.png"
#                $outputParam = $svgFile.BaseName + ".ico"
#                & $imagemagicExe $inputParam $outputParam
#removce pngs
				
}

}