$inkscapeExe = "C:\Program Files\Inkscape\inkscape.exe"
$imagemagicExe = "C:\Program Files\ImageMagick\convert.exe"
$svgFolderRaw = "."
$svgFolder = "./svg"

#$sizeArray = 32,48,96 #Android


$svgFiles = Get-ChildItem $svgFolderRaw -Filter *.svg
$pause = 0
				$foldername = "svg"
				new-item ./ -Name $foldername -Force -ItemType directory
				$foldername = "png"
				new-item ./ -Name $foldername -Force -ItemType directory
				

$c=0
if ($svgFiles.Length -ne 0){

    Write-Host "All" $svgFiles.Length "icon to output"
    	
    foreach ($svgFile in $svgFiles)
    {
        $inputParam  = $svgFile.FullName 

	    $outputParam = "--export-plain-svg="  + ".\svg\" + $svgFile.BaseName + ".svg"
	    & $inkscapeExe $inputParam $outputParam
	    $pause += 1
	
	    sleep -seconds 1
	
	    $inputParam  = ".\svg\" + $svgFile.BaseName + ".svg"
	                    
                                    $outputParam = "--export-png=./png/"+  $svgFile.BaseName + ".png"
								    $widthParam = ""
                                    $heightParam = "" 
                                    & $inkscapeExe $inputParam $outputParam $widthParam $heightParam
                    
        $c =$c+1
        sleep -seconds 1
        Write-Host $c "/" $svgFiles.Length $svgFile.BaseName
	    rm $svgFile
    }
} 
Else {

    $svgFiles = Get-ChildItem $svgFolder -Filter *.svg

    Write-Host "All" $svgFiles.Length "icon to output"

    foreach ($svgFile in $svgFiles)
    {
	
	    $inputParam  = ".\svg\" + $svgFile.BaseName + ".svg"
	                    foreach ($sizeValue in $sizeArray)
                    {
                                    $outputParam = "--export-png=./png/"+  $svgFile.BaseName + ".png"
								    $widthParam = ""
                                    $heightParam = ""
                                    & $inkscapeExe $inputParam $outputParam $widthParam $heightParam
                    }
    $c =$c+1
    Write-Host $c "/" $svgFiles.Length $svgFile.BaseName
    }

}