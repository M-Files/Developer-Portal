$inkscapeExe = "C:\Program Files\Inkscape\inkscape.exe"
$imagemagicExe = "C:\Program Files\ImageMagick\convert.exe"
$svgFolderRaw = "."
$svgFolder = "./svg"
$sizeArray = 16,24,32,48,64,96,512

$svgFiles = Get-ChildItem $svgFolderRaw -Filter *.svg
$pause = 0
				$foldername = "svg"
				new-item ./ -Name $foldername -Force -ItemType directory
				$foldername = "png_temp"
				new-item ./ -Name $foldername -Force -ItemType directory
				$foldername = "ico"
				new-item ./ -Name $foldername -Force -ItemType directory
$c=0			
if ($svgFiles.Length -ne 0){
	
	Write-Host "**All" $svgFiles.Length "icon to output"
	Write-Host "**Starting svg optimization and preparing pngs for ico composing"
	foreach ($svgFile in $svgFiles)
	{
	    $inputParam  = $svgFile.FullName 

	    $outputParam = "--export-plain-svg="  + ".\svg\" + $svgFile.BaseName + ".svg"
		& $inkscapeExe $inputParam $outputParam
	    $pause += 1
	
	    sleep -seconds 1
		
		$inputParam  = ".\svg\" + $svgFile.BaseName + ".svg"
					foreach ($sizeValue in $sizeArray)
					{
									$outputParam = "--export-png=./png_temp/" +  $svgFile.BaseName + $sizeValue + ".png"
									$widthParam  = "-w" + $sizeValue
									$heightParam = "-h" + $sizeValue
									& $inkscapeExe $inputParam $outputParam $widthParam $heightParam
					}
        $c =$c+1
        sleep -seconds 1
        
	}
	# Flush files to disk
	sleep -seconds 5
	$c=0
	Write-Host "**Starting svg exporting"
	foreach ($svgFile in $svgFiles)
	{
		$inputParam  = "./png_temp/" + $svgFile.BaseName + "*.png"
		$outputParam = "./ico/" + $svgFile.BaseName + ".ico"
		& $imagemagicExe $inputParam $outputParam
		
        $c =$c+1
        sleep -seconds 1
        Write-Host $c "/" $svgFiles.Length $svgFile.BaseName
		rm $svgFile
	}
}
#Disabled for slow computers, delete png_temp manually
#sleep -seconds 3
#Remove-Item .\png_temp -Force -Recurse