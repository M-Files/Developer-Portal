
public ObjectVersion GetObjectVersion( int type, string id, string version )
{
    // Construct the URL by filling type, id and version.
    string url = string.Format(
        "http://example.org/REST/objects/{0}/{1}/{2}",
        type, id, version );

    // Create the web request.
    WebRequest request = WebRequest.Create( url );

    // Fill the authentication information.
    request.Headers["X-Authentication"] = this.AuthenticationToken;

    // Receive the response.
    var response = request.GetResponse();

    // Use DataContractJsonSerializer to deserialize the JSON formatted
    // ObjectVersion information from the response stream.
    var serializer = new DataContractJsonSerializer( typeof( ObjectVersion ) );
    var objectVersion = (ObjectVersion)serializer.ReadObject( response.GetResponseStream() );

    return objectVersion;
}
