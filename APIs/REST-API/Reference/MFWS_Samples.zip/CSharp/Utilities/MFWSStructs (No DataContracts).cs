// M-Files Web Service data types.
//
// These M-Files Web Service data types are plain types with no decorators.
// They can be used with third party serializers without other dependncies
// within .NET Framework.


// Copyright 2012 M-Files Corporation
// http://www.m-files.com/
// 
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//
//
//

using System;

// Requires System.Runtime.Serialization reference.
using System.Runtime.Serialization;

namespace MFiles.Mfws.Structs
{



    /// <summary>
    /// Specifies the information required when creating a new object.
    /// </summary>
    public class ObjectCreationInfo
    {

        /// <summary>
        /// Properties for the new object.
        /// </summary>
        public PropertyValue[] PropertyValues { get; set; }
        
        /// <summary>
        /// References previously uploaded files.
        /// </summary>
        public UploadInfo[] Files { get; set; }
        
    }

    

    /// <summary>
    /// Contains the information on an uploaded file.
    /// </summary>
    public class UploadInfo
    {

        /// <summary>
        /// Obsolete. Temporary upload ID given by the server, if the file was uploaded in an upload session. Null for a stateless upload.
        /// </summary>
        public int? UploadID { get; set; }
        
        /// <summary>
        /// The file reference of a stateless upload (?statelessUpload=true), which any server instance can use. Set instead of UploadID. M-Files MFILES_VERSION_TBD and later.
        /// </summary>
        public string FileRef { get; set; }
        
        /// <summary>
        /// The maximum size of a block in bytes. Returned by /files/upload for a stateless upload.
        /// </summary>
        public long? MaxBlockSize { get; set; }
        
        /// <summary>
        /// True if the blocks must be uploaded in order, one at a time. Returned by /files/upload for a stateless upload.
        /// </summary>
        public bool? RequireSequentialBlocks { get; set; }
        
        /// <summary>
        /// File name without extension.
        /// </summary>
        public string Title { get; set; }
        
        /// <summary>
        /// File extension.
        /// </summary>
        public string Extension { get; set; }
        
        /// <summary>
        /// File size.
        /// </summary>
        public long Size { get; set; }
        
    }

    

    /// <summary>
    /// A &#39;typed value&#39; represents a value, such as text, number, date or lookup item.
    /// </summary>
    public class TypedValue
    {

        /// <summary>
        /// Specifies the type of the value.
        /// </summary>
        public MFDataType DataType { get; set; }
        
        /// <summary>
        /// Specifies whether the typed value contains a real value.
        /// </summary>
        public bool HasValue { get; set; }
        
        /// <summary>
        /// Specifies the string, number or boolean value when the DataType is not a lookup type.
        /// </summary>
        public object Value { get; set; }
        
        /// <summary>
        /// Specifies the lookup value when the DataType is Lookup.
        /// </summary>
        public Lookup Lookup { get; set; }
        
        /// <summary>
        /// Specifies the collection of \type{Lookup}s when the DataType is MultiSelectLookup.
        /// </summary>
        public Lookup[] Lookups { get; set; }
        
        /// <summary>
        /// Provides the value formatted for display.
        /// </summary>
        public string DisplayValue { get; set; }
        
        /// <summary>
        /// Provides a key that can be used to sort \type{TypedValue}s
        /// </summary>
        public string SortingKey { get; set; }
        
        /// <summary>
        /// Provides the typed value in a serialized format suitable to be used in URIs.
        /// </summary>
        public string SerializedValue { get; set; }
        
    }

    

    /// <summary>
    /// An object version with extended properties. Inherits from ObjectVersion.
    /// </summary>
    public class ExtendedObjectVersion
    {

        /// <summary>
        /// Object properties
        /// </summary>
        public PropertyValue[] Properties { get; set; }
        
    }

    

    /// <summary>
    /// Authentication details.
    /// </summary>
    public class Authentication
    {

        /// <summary>
        /// 
        /// </summary>
        public string Username { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string Password { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string Domain { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public bool WindowsUser { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string ComputerName { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string VaultGuid { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public DateTime? Expiration { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public bool ReadOnly { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string URL { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string Method { get; set; }
        
    }

    

    /// <summary>
    /// Vault information.
    /// </summary>
    public class Vault
    {

        /// <summary>
        /// Vault name.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Vault GUID.
        /// </summary>
        public string GUID { get; set; }
        
        /// <summary>
        /// Vault-specific authentication token.
        /// </summary>
        public string Authentication { get; set; }
        
    }

    

    /// <summary>
    /// Information required for changing password.
    /// </summary>
    public class PasswordChange
    {

        /// <summary>
        /// The current password.
        /// </summary>
        public string OldPassword { get; set; }
        
        /// <summary>
        /// The new password.
        /// </summary>
        public string NewPassword { get; set; }
        
    }

    

    /// <summary>
    /// Server public key information.
    /// </summary>
    public class PublicKey
    {

        /// <summary>
        /// Base64URL encoded exponent.
        /// </summary>
        public string Exponent { get; set; }
        
        /// <summary>
        /// Base64URL encoded modulus.
        /// </summary>
        public string Modulus { get; set; }
        
    }

    

    /// <summary>
    /// Response for status requests.
    /// </summary>
    public class StatusResponse
    {

        /// <summary>
        /// The result of the status request.
        /// </summary>
        public bool Successful { get; set; }
        
        /// <summary>
        /// Display message for the status.
        /// </summary>
        public string Message { get; set; }
        
    }

    

    /// <summary>
    /// An object class with extended properties. Inherits from ObjectClass.
    /// </summary>
    public class ExtendedObjectClass
    {

        /// <summary>
        /// Property definitions associated with this class.
        /// </summary>
        public AssociatedPropertyDef[] AssociatedPropertyDefs { get; set; }
        
        /// <summary>
        /// Templates available for use with this class.
        /// </summary>
        public ObjectVersion[] Templates { get; set; }
        
    }

    

    /// <summary>
    /// Workflow state information.
    /// </summary>
    public class WorkflowState
    {

        /// <summary>
        /// Workflow state name.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Workflow state ID.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Defines whether this state is selectable for the current object.
        /// </summary>
        public bool Selectable { get; set; }
        
    }

    

    /// <summary>
    /// An object version with extended properties. Inherits from ObjectVersion.
    /// </summary>
    public class FolderContentItems
    {

        /// <summary>
        /// The path to the current folder.
        /// </summary>
        public string Path { get; set; }
        
        /// <summary>
        /// Specifies whether there are more results in the folder.
        /// </summary>
        public bool MoreResults { get; set; }
        
        /// <summary>
        /// The actual folder contents.
        /// </summary>
        public FolderContentItem[] Items { get; set; }
        
    }

    

    /// <summary>
    /// A workflow state on an object.
    /// </summary>
    public class ObjectWorkflowState
    {

        /// <summary>
        /// The workflow state defined as a property value.
        /// </summary>
        public PropertyValue State { get; set; }
        
        /// <summary>
        /// The workflow state ID.
        /// </summary>
        public int StateID { get; set; }
        
        /// <summary>
        /// The workflow state name.
        /// </summary>
        public string StateName { get; set; }
        
        /// <summary>
        /// The workflow defined as a property value.
        /// </summary>
        public PropertyValue Workflow { get; set; }
        
        /// <summary>
        /// The workflow ID.
        /// </summary>
        public int WorkflowID { get; set; }
        
        /// <summary>
        /// The workflow name.
        /// </summary>
        public string WorkflowName { get; set; }
        
        /// <summary>
        /// Version comment defined on the workflow transition.
        /// </summary>
        public string VersionComment { get; set; }
        
    }

    

    /// <summary>
    /// M-Files Web Service error object.
    /// </summary>
    public class WebServiceError
    {

        /// <summary>
        /// HTTP Status code
        /// </summary>
        public int Status { get; set; }
        
        /// <summary>
        /// The request URL which caused this error.
        /// </summary>
        public string URL { get; set; }
        
        /// <summary>
        /// The request method.
        /// </summary>
        public string Method { get; set; }
        
        /// <summary>
        /// Detailed information on the exception.
        /// </summary>
        public ExceptionInfo Exception { get; set; }
        
    }

    

    /// <summary>
    /// 
    /// </summary>
    public class ExceptionInfo
    {

        /// <summary>
        /// Error message.
        /// </summary>
        public string Message { get; set; }
        
        /// <summary>
        /// Underlying error that caused this one.
        /// </summary>
        public ExceptionInfo InnerException { get; set; }
        
        /// <summary>
        /// M-Files Web Service server-side stack trace.
        /// </summary>
        public StackTraceElement[] Stack { get; set; }
        
    }

    

    /// <summary>
    /// M-Files Web Service error stack trace element.
    /// </summary>
    public class StackTraceElement
    {

        /// <summary>
        /// 
        /// </summary>
        public string FileName { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public int LineNumber { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string ClassName { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string MethodName { get; set; }
        
    }

    

    /// <summary>
    /// Results of a query which might leave only a partial set of items.
    /// </summary>
    public class Results<T>
    {

        /// <summary>
        /// Contains results of a query
        /// </summary>
        public T[] Items { get; set; }
        
        /// <summary>
        /// True if there were more results which were left out.
        /// </summary>
        public bool MoreResults { get; set; }
        
    }

    

    /// <summary>
    /// 
    /// </summary>
    public class PrimitiveType<T>
    {

        /// <summary>
        /// Primitive value.
        /// </summary>
        public T Value { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ObjectVersion
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public DateTime AccessedByMeUtc { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public DateTime CheckedOutAtUtc { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int CheckedOutTo { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string CheckedOutToUserName { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Class { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public DateTime CreatedUtc { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool Deleted { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string DisplayID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public ObjectFile[] Files { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool HasAssignments { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool HasRelationshipsFromThis { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool HasRelationshipsToThis { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool IsStub { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public DateTime LastModifiedUtc { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool ObjectCheckedOut { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool ObjectCheckedOutToThisUser { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public MFObjectVersionFlag ObjectVersionFlags { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public ObjVer ObjVer { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool SingleFile { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool ThisVersionLatestToThisUser { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Title { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool VisibleAfterOperation { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ObjectFile
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public DateTime ChangeTimeUtc { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Extension { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Version { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ObjVer
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Type { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Version { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class PropertyValue
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int PropertyDef { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public TypedValue TypedValue { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class SessionInfo
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string AccountName { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public MFACLMode ACLMode { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public MFAuthType AuthenticationType { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool CanForceUndoCheckout { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool CanManageCommonUISettings { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool CanManageCommonViews { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool CanManageTraditionalFolders { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool CanMaterializeViews { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool CanSeeAllObjects { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool CanSeeDeletedObjects { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool InternalUser { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool LicenseAllowsModifications { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int UserID { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ObjType
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool AllowAdding { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool CanHaveFiles { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int DefaultPropertyDef { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool External { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string NamePlural { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int OwnerPropertyDef { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int[] ReadOnlyPropertiesDuringInsert { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int[] ReadOnlyPropertiesDuringUpdate { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool RealObjectType { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class PropertyDef
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool AllObjectTypes { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string AutomaticValue { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public MFAutomaticValueType AutomaticValueType { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool BasedOnValueList { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public MFDataType DataType { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ObjectType { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ValueList { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class Workflow
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ObjectClass { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ValueListItem
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string DisplayID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool HasOwner { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool HasParent { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int OwnerID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ParentID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ValueListID { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ObjID
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Type { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class Lookup
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool Deleted { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string DisplayValue { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool Hidden { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Item { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Version { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class VersionComment
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public PropertyValue LastModifiedBy { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public ObjVer ObjVer { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public PropertyValue StatusChanged { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public PropertyValue Comment { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class AssociatedPropertyDef
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int PropertyDef { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool Required { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class FolderContentItem
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public MFFolderContentItemType FolderContentItemType { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public ObjectVersion ObjectVersion { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public TypedValue PropertyFolder { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public Lookup TraditionalFolder { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public View View { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class View
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool Common { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Parent { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public ViewLocation ViewLocation { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ViewLocation
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public TypedValue OverlappedFolder { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public bool Overlapping { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ObjectClass
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int ID { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int NamePropertyDef { get; set; }
        
        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public int Workflow { get; set; }
        
    }

    

    /// <summary>
    /// Based on M-Files API.
    /// </summary>
    public class ClassGroup
    {

        /// <summary>
        /// Based on M-Files API.
        /// </summary>
        public string Name { get; set; }
        
    }

    


	/// <summary>
	/// 
	/// </summary>
	public enum MFCheckOutStatus
	{


		/// <summary>
		/// Object is checked in.
		/// </summary>
		CheckedIn  = 0,
		

		/// <summary>
		/// Object is checked out to someone else.
		/// </summary>
		CheckedOut  = 1,
		

		/// <summary>
		/// Object is checked out to the current user.
		/// </summary>
		CheckedOutToMe  = 2,
		
	}

    

	/// <summary>
	/// 
	/// </summary>
	public enum MFRefreshStatus
	{


		/// <summary>
		/// 
		/// </summary>
		None  = 0,
		

		/// <summary>
		/// 
		/// </summary>
		Quick  = 1,
		

		/// <summary>
		/// 
		/// </summary>
		Full  = 2,
		
	}

    

	/// <summary>
	/// 
	/// </summary>
	public enum MFObjectVersionFlag
	{


		/// <summary>
		/// 
		/// </summary>
		None  = 0,
		

		/// <summary>
		/// 
		/// </summary>
		Completed  = 1,
		

		/// <summary>
		/// 
		/// </summary>
		HasRelatedObjects  = 2,
		
	}

    

	/// <summary>
	/// 
	/// </summary>
	public enum MFAuthType
	{


		/// <summary>
		/// 
		/// </summary>
		Unknown  = 0,
		

		/// <summary>
		/// 
		/// </summary>
		LoggedOnWindowsUser  = 1,
		

		/// <summary>
		/// 
		/// </summary>
		SpecificWindowsUser  = 2,
		

		/// <summary>
		/// 
		/// </summary>
		SpecificMFilesUser  = 3,
		
	}

    

	/// <summary>
	/// 
	/// </summary>
	public enum MFACLMode
	{


		/// <summary>
		/// 
		/// </summary>
		Simple  = 0,
		

		/// <summary>
		/// 
		/// </summary>
		AutomaticPermissionsWithComponents  = 1,
		
	}

    

	/// <summary>
	/// 
	/// </summary>
	public enum MFDataType
	{


		/// <summary>
		/// 
		/// </summary>
		Uninitialized  = 0,
		

		/// <summary>
		/// 
		/// </summary>
		Text  = 1,
		

		/// <summary>
		/// 
		/// </summary>
		Integer  = 2,
		

		/// <summary>
		/// 
		/// </summary>
		Floating  = 3,
		

		/// <summary>
		/// 
		/// </summary>
		Date  = 5,
		

		/// <summary>
		/// 
		/// </summary>
		Time  = 6,
		

		/// <summary>
		/// 
		/// </summary>
		Timestamp  = 7,
		

		/// <summary>
		/// 
		/// </summary>
		Boolean  = 8,
		

		/// <summary>
		/// 
		/// </summary>
		Lookup  = 9,
		

		/// <summary>
		/// 
		/// </summary>
		MultiSelectLookup  = 10,
		

		/// <summary>
		/// 
		/// </summary>
		Integer64  = 11,
		

		/// <summary>
		/// 
		/// </summary>
		FILETIME  = 12,
		

		/// <summary>
		/// 
		/// </summary>
		MultiLineText  = 13,
		

		/// <summary>
		/// 
		/// </summary>
		ACL  = 14,
		
	}

    

	/// <summary>
	/// 
	/// </summary>
	public enum MFAutomaticValueType
	{


		/// <summary>
		/// 
		/// </summary>
		None  = 0,
		

		/// <summary>
		/// 
		/// </summary>
		CalculatedWithPlaceholders  = 1,
		

		/// <summary>
		/// 
		/// </summary>
		CalculatedWithVBScript  = 2,
		

		/// <summary>
		/// 
		/// </summary>
		AutoNumberSimple  = 3,
		

		/// <summary>
		/// 
		/// </summary>
		WithVBScript  = 4,
		
	}

    

	/// <summary>
	/// 
	/// </summary>
	public enum MFFolderContentItemType
	{


		/// <summary>
		/// 
		/// </summary>
		Unknown  = 0,
		

		/// <summary>
		/// 
		/// </summary>
		ViewFolder  = 1,
		

		/// <summary>
		/// 
		/// </summary>
		PropertyFolder  = 2,
		

		/// <summary>
		/// 
		/// </summary>
		TraditionalFolder  = 3,
		

		/// <summary>
		/// 
		/// </summary>
		ObjectVersion  = 4,
		
	}

    
}
